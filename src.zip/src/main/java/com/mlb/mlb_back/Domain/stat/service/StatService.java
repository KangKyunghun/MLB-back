package com.mlb.mlb_back.Domain.stat.service;

import com.mlb.mlb_back.Domain.stat.dto.*;
import com.mlb.mlb_back.Domain.stat.entity.*;
import com.mlb.mlb_back.Domain.stat.repository.*;
import com.mlb.mlb_back.Global.exception.ApiException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class StatService {

    private final BatterStatRepository batterStatRepository;
    private final PitcherStatRepository pitcherStatRepository;
    private final HotColdZoneRepository hotColdZoneRepository;
    private final SprayDataRepository sprayDataRepository;
    private final PlayerMonthlyStatRepository playerMonthlyStatRepository;
    private final BatterSituationStatRepository batterSituationStatRepository;
    private final BatterVsPitcherRepository batterVsPitcherRepository;

    // ── 타자 스탯 ─────────────────────────────────────────────

    // 특정 선수 타자 스탯 전체 (시즌별, gameType별)
    // gameType 없으면 전체, 있으면 필터
    public List<BatterStatResponse> getBatterStats(Long playerId, String gameType) {
        List<BatterStat> stats = (gameType != null)
                ? batterStatRepository.findByPlayerIdAndGameType(playerId, gameType)
                : batterStatRepository.findByPlayerId(playerId);
        return stats.stream()
                .sorted(Comparator.comparing(s -> -s.getSeason()))
                .map(BatterStatResponse::from)
                .collect(Collectors.toList());
    }

    // 특정 선수 특정 시즌 타자 스탯
    public BatterStatResponse getBatterStatBySeason(Long playerId, Integer season, String gameType) {
        return batterStatRepository.findByPlayerIdAndSeasonAndGameType(playerId, season, gameType)
                .stream()
                .findFirst()
                .map(BatterStatResponse::from)
                .orElseThrow(() -> ApiException.notFound(
                        "타자 스탯을 찾을 수 없습니다: playerId=" + playerId + ", season=" + season + ", gameType=" + gameType));
    }

    // 시즌 타자 리더보드
    public List<BatterStatResponse> getBatterLeaderboard(Integer season, String gameType, String statType, int limit) {
        int minAtBats = gameType.equals("R") ? 100 : 10; // 포스트시즌은 최소 타수 기준 완화
        return batterStatRepository.findBySeasonAndGameType(season, gameType)
                .stream()
                .filter(s -> s.getAtBats() != null && s.getAtBats() >= minAtBats)
                .sorted(getBatterLeaderboardComparator(statType))
                .limit(limit)
                .map(BatterStatResponse::from)
                .collect(Collectors.toList());
    }

    // 팀별 타자 스탯
    public List<BatterStatResponse> getBatterStatsByTeam(Long teamId, Integer season, String gameType) {
        return batterStatRepository.findByTeamIdAndSeasonAndGameType(teamId, season, gameType)
                .stream()
                .map(BatterStatResponse::from)
                .collect(Collectors.toList());
    }

    private Comparator<BatterStat> getBatterLeaderboardComparator(String statType) {
        return switch (statType) {
            case "obp" -> Comparator.comparing((BatterStat s) -> s.getObp() != null ? s.getObp() : 0.0).reversed();
            case "slg" -> Comparator.comparing((BatterStat s) -> s.getSlg() != null ? s.getSlg() : 0.0).reversed();
            case "ops" -> Comparator.comparing((BatterStat s) -> s.getOps() != null ? s.getOps() : 0.0).reversed();
            case "babip" -> Comparator.comparing((BatterStat s) -> s.getBabip() != null ? s.getBabip() : 0.0).reversed();
            case "hits" -> Comparator.comparing((BatterStat s) -> s.getHits() != null ? s.getHits() : 0).reversed();
            case "doubles" -> Comparator.comparing((BatterStat s) -> s.getDoubles() != null ? s.getDoubles() : 0).reversed();
            case "triples" -> Comparator.comparing((BatterStat s) -> s.getTriples() != null ? s.getTriples() : 0).reversed();
            case "homeRuns" -> Comparator.comparing((BatterStat s) -> s.getHomeRuns() != null ? s.getHomeRuns() : 0).reversed();
            case "totalBases" -> Comparator.comparing((BatterStat s) -> s.getTotalBases() != null ? s.getTotalBases() : 0).reversed();
            case "runs" -> Comparator.comparing((BatterStat s) -> s.getRuns() != null ? s.getRuns() : 0).reversed();
            case "rbi" -> Comparator.comparing((BatterStat s) -> s.getRbi() != null ? s.getRbi() : 0).reversed();
            case "walks" -> Comparator.comparing((BatterStat s) -> s.getWalks() != null ? s.getWalks() : 0).reversed();
            case "intentionalWalks" -> Comparator.comparing((BatterStat s) -> s.getIntentionalWalks() != null ? s.getIntentionalWalks() : 0).reversed();
            case "hitByPitch" -> Comparator.comparing((BatterStat s) -> s.getHitByPitch() != null ? s.getHitByPitch() : 0).reversed();
            case "stolenBases" -> Comparator.comparing((BatterStat s) -> s.getStolenBases() != null ? s.getStolenBases() : 0).reversed();
            case "caughtStealing" -> Comparator.comparing((BatterStat s) -> s.getCaughtStealing() != null ? s.getCaughtStealing() : 0).reversed();
            case "strikeOuts" -> Comparator.comparing((BatterStat s) -> s.getStrikeOuts() != null ? s.getStrikeOuts() : 0).reversed();
            case "groundIntoDoublePlay" -> Comparator.comparing((BatterStat s) -> s.getGroundIntoDoublePlay() != null ? s.getGroundIntoDoublePlay() : 0).reversed();
            case "sacBunts" -> Comparator.comparing((BatterStat s) -> s.getSacBunts() != null ? s.getSacBunts() : 0).reversed();
            case "sacFlies" -> Comparator.comparing((BatterStat s) -> s.getSacFlies() != null ? s.getSacFlies() : 0).reversed();
            case "leftOnBase" -> Comparator.comparing((BatterStat s) -> s.getLeftOnBase() != null ? s.getLeftOnBase() : 0).reversed();
            case "groundOuts" -> Comparator.comparing((BatterStat s) -> s.getGroundOuts() != null ? s.getGroundOuts() : 0).reversed();
            case "airOuts" -> Comparator.comparing((BatterStat s) -> s.getAirOuts() != null ? s.getAirOuts() : 0).reversed();
            case "groundOutsToAirOuts" -> Comparator.comparing((BatterStat s) -> s.getGroundOutsToAirOuts() != null ? s.getGroundOutsToAirOuts() : 0.0).reversed();
            case "numberOfPitches" -> Comparator.comparing((BatterStat s) -> s.getNumberOfPitches() != null ? s.getNumberOfPitches() : 0).reversed();
            case "atBatsPerHomeRun" -> Comparator.comparing((BatterStat s) -> s.getAtBatsPerHomeRun() != null ? s.getAtBatsPerHomeRun() : Double.MAX_VALUE);
            case "plateAppearances" -> Comparator.comparing((BatterStat s) -> s.getPlateAppearances() != null ? s.getPlateAppearances() : 0).reversed();
            case "atBats" -> Comparator.comparing((BatterStat s) -> s.getAtBats() != null ? s.getAtBats() : 0).reversed();
            default -> Comparator.comparing((BatterStat s) -> s.getAvg() != null ? s.getAvg() : 0.0).reversed();
        };
    }

    // ── 투수 스탯 ─────────────────────────────────────────────

    // 특정 선수 투수 스탯 전체 (시즌별, gameType별)
    public List<PitcherStatResponse> getPitcherStats(Long playerId, String gameType) {
        List<PitcherStat> stats = (gameType != null)
                ? pitcherStatRepository.findByPlayerIdAndGameType(playerId, gameType)
                : pitcherStatRepository.findByPlayerId(playerId);
        return stats.stream()
                .sorted(Comparator.comparing(s -> -s.getSeason()))
                .map(PitcherStatResponse::from)
                .collect(Collectors.toList());
    }

    // 특정 선수 특정 시즌 투수 스탯
    public PitcherStatResponse getPitcherStatBySeason(Long playerId, Integer season, String gameType) {
        return pitcherStatRepository.findByPlayerIdAndSeasonAndGameType(playerId, season, gameType)
                .stream()
                .findFirst()
                .map(PitcherStatResponse::from)
                .orElseThrow(() -> ApiException.notFound(
                        "투수 스탯을 찾을 수 없습니다: playerId=" + playerId + ", season=" + season + ", gameType=" + gameType));
    }

    // 시즌 투수 리더보드
    public List<PitcherStatResponse> getPitcherLeaderboard(Integer season, String gameType, String statType, int limit) {
        double minInnings = gameType.equals("R") ? 20.0 : 5.0; // 포스트시즌은 최소 이닝 기준 완화
        return pitcherStatRepository.findBySeasonAndGameType(season, gameType)
                .stream()
                .filter(s -> s.getInningsPitched() != null && s.getInningsPitched() >= minInnings)
                .sorted(getPitcherLeaderboardComparator(statType))
                .limit(limit)
                .map(PitcherStatResponse::from)
                .collect(Collectors.toList());
    }

    // 팀별 투수 스탯
    public List<PitcherStatResponse> getPitcherStatsByTeam(Long teamId, Integer season, String gameType) {
        return pitcherStatRepository.findByTeamIdAndSeasonAndGameType(teamId, season, gameType)
                .stream()
                .map(PitcherStatResponse::from)
                .collect(Collectors.toList());
    }

    private Comparator<PitcherStat> getPitcherLeaderboardComparator(String statType) {
        return switch (statType) {
            case "wins" -> Comparator.comparing((PitcherStat s) -> s.getWins() != null ? s.getWins() : 0).reversed();
            case "losses" -> Comparator.comparing((PitcherStat s) -> s.getLosses() != null ? s.getLosses() : 0);
            case "saves" -> Comparator.comparing((PitcherStat s) -> s.getSaves() != null ? s.getSaves() : 0).reversed();
            case "saveOpportunities" -> Comparator.comparing((PitcherStat s) -> s.getSaveOpportunities() != null ? s.getSaveOpportunities() : 0).reversed();
            case "blownSaves" -> Comparator.comparing((PitcherStat s) -> s.getBlownSaves() != null ? s.getBlownSaves() : 0).reversed();
            case "holds" -> Comparator.comparing((PitcherStat s) -> s.getHolds() != null ? s.getHolds() : 0).reversed();
            case "winPercentage" -> Comparator.comparing((PitcherStat s) -> s.getWinPercentage() != null ? s.getWinPercentage() : 0.0).reversed();
            case "inningsPitched" -> Comparator.comparing((PitcherStat s) -> s.getInningsPitched() != null ? s.getInningsPitched() : 0.0).reversed();
            case "outs" -> Comparator.comparing((PitcherStat s) -> s.getOuts() != null ? s.getOuts() : 0).reversed();
            case "battersFaced" -> Comparator.comparing((PitcherStat s) -> s.getBattersFaced() != null ? s.getBattersFaced() : 0).reversed();
            case "hitsAllowed" -> Comparator.comparing((PitcherStat s) -> s.getHitsAllowed() != null ? s.getHitsAllowed() : 0).reversed();
            case "homeRunsAllowed" -> Comparator.comparing((PitcherStat s) -> s.getHomeRunsAllowed() != null ? s.getHomeRunsAllowed() : 0).reversed();
            case "doubles" -> Comparator.comparing((PitcherStat s) -> s.getDoubles() != null ? s.getDoubles() : 0).reversed();
            case "triples" -> Comparator.comparing((PitcherStat s) -> s.getTriples() != null ? s.getTriples() : 0).reversed();
            case "groundOuts" -> Comparator.comparing((PitcherStat s) -> s.getGroundOuts() != null ? s.getGroundOuts() : 0).reversed();
            case "airOuts" -> Comparator.comparing((PitcherStat s) -> s.getAirOuts() != null ? s.getAirOuts() : 0).reversed();
            case "groundOutsToAirOuts" -> Comparator.comparing((PitcherStat s) -> s.getGroundOutsToAirOuts() != null ? s.getGroundOutsToAirOuts() : 0.0).reversed();
            case "walks" -> Comparator.comparing((PitcherStat s) -> s.getWalks() != null ? s.getWalks() : 0).reversed();
            case "intentionalWalks" -> Comparator.comparing((PitcherStat s) -> s.getIntentionalWalks() != null ? s.getIntentionalWalks() : 0).reversed();
            case "hitBatsmen" -> Comparator.comparing((PitcherStat s) -> s.getHitBatsmen() != null ? s.getHitBatsmen() : 0).reversed();
            case "runs" -> Comparator.comparing((PitcherStat s) -> s.getRuns() != null ? s.getRuns() : 0).reversed();
            case "earnedRuns" -> Comparator.comparing((PitcherStat s) -> s.getEarnedRuns() != null ? s.getEarnedRuns() : 0).reversed();
            case "strikeOuts" -> Comparator.comparing((PitcherStat s) -> s.getStrikeOuts() != null ? s.getStrikeOuts() : 0).reversed();
            case "numberOfPitches" -> Comparator.comparing((PitcherStat s) -> s.getNumberOfPitches() != null ? s.getNumberOfPitches() : 0).reversed();
            case "strikePercentage" -> Comparator.comparing((PitcherStat s) -> s.getStrikePercentage() != null ? s.getStrikePercentage() : 0.0).reversed();
            case "pitchesPerInning" -> Comparator.comparing((PitcherStat s) -> s.getPitchesPerInning() != null ? s.getPitchesPerInning() : 0.0).reversed();
            case "wildPitches" -> Comparator.comparing((PitcherStat s) -> s.getWildPitches() != null ? s.getWildPitches() : 0).reversed();
            case "sacBunts" -> Comparator.comparing((PitcherStat s) -> s.getSacBunts() != null ? s.getSacBunts() : 0).reversed();
            case "sacFlies" -> Comparator.comparing((PitcherStat s) -> s.getSacFlies() != null ? s.getSacFlies() : 0).reversed();
            case "groundIntoDoublePlay" -> Comparator.comparing((PitcherStat s) -> s.getGroundIntoDoublePlay() != null ? s.getGroundIntoDoublePlay() : 0).reversed();
            case "era" -> Comparator.comparing((PitcherStat s) -> s.getEra() != null ? s.getEra() : 99.0);
            case "whip" -> Comparator.comparing((PitcherStat s) -> s.getWhip() != null ? s.getWhip() : 99.0);
            case "avgAllowed" -> Comparator.comparing((PitcherStat s) -> s.getAvgAllowed() != null ? s.getAvgAllowed() : 99.0);
            case "obpAllowed" -> Comparator.comparing((PitcherStat s) -> s.getObpAllowed() != null ? s.getObpAllowed() : 99.0);
            case "slgAllowed" -> Comparator.comparing((PitcherStat s) -> s.getSlgAllowed() != null ? s.getSlgAllowed() : 99.0);
            case "opsAllowed" -> Comparator.comparing((PitcherStat s) -> s.getOpsAllowed() != null ? s.getOpsAllowed() : 99.0);
            case "babip" -> Comparator.comparing((PitcherStat s) -> s.getBabip() != null ? s.getBabip() : 99.0);
            case "strikeOutPer9" -> Comparator.comparing((PitcherStat s) -> s.getStrikeOutPer9() != null ? s.getStrikeOutPer9() : 0.0).reversed();
            case "walkPer9" -> Comparator.comparing((PitcherStat s) -> s.getWalkPer9() != null ? s.getWalkPer9() : 99.0);
            case "hitsPer9" -> Comparator.comparing((PitcherStat s) -> s.getHitsPer9() != null ? s.getHitsPer9() : 99.0);
            case "homeRunsPer9" -> Comparator.comparing((PitcherStat s) -> s.getHomeRunsPer9() != null ? s.getHomeRunsPer9() : 99.0);
            case "runsScoredPer9" -> Comparator.comparing((PitcherStat s) -> s.getRunsScoredPer9() != null ? s.getRunsScoredPer9() : 99.0);
            case "strikeoutWalkRatio" -> Comparator.comparing((PitcherStat s) -> s.getStrikeoutWalkRatio() != null ? s.getStrikeoutWalkRatio() : 0.0).reversed();
            default -> Comparator.comparing((PitcherStat s) -> s.getEra() != null ? s.getEra() : 99.0);
        };
    }

    // ── 핫콜드존 ──────────────────────────────────────────────

    public HotColdZoneResponse getHotColdZone(Long playerId, Integer season, String gameType) {
        return hotColdZoneRepository.findByPlayerId(playerId).stream()
                .filter(z -> z.getSeason().equals(season) && z.getGameType().equals(gameType))
                .findFirst()
                .map(HotColdZoneResponse::from)
                .orElseThrow(() -> ApiException.notFound(
                        "핫콜드존 데이터를 찾을 수 없습니다: playerId=" + playerId + ", season=" + season + ", gameType=" + gameType));
    }

    public List<HotColdZoneResponse> getHotColdZonesAll(Long playerId) {
        return hotColdZoneRepository.findByPlayerId(playerId).stream()
                .sorted(Comparator.comparing(HotColdZone::getSeason).reversed())
                .map(HotColdZoneResponse::from)
                .collect(Collectors.toList());
    }

    // ── 스프레이차트 ───────────────────────────────────────────

    public List<SprayDataResponse> getSprayData(Long playerId, Integer season, String gameType) {
        List<SprayData> data = switch (gameType) {
            case "R"  -> sprayDataRepository.findByPlayerRegularSeason(playerId, season);
            case "W"  -> sprayDataRepository.findByPlayerWildCard(playerId, season);
            case "D"  -> sprayDataRepository.findByPlayerDivisionSeries(playerId, season);
            case "L"  -> sprayDataRepository.findByPlayerChampionshipSeries(playerId, season);
            case "F"  -> sprayDataRepository.findByPlayerWorldSeries(playerId, season);
            case "PS" -> sprayDataRepository.findByPlayerPostSeason(playerId, season);
            default   -> sprayDataRepository.findByPlayerRegularSeason(playerId, season);
        };
        return data.stream()
                .map(SprayDataResponse::from)
                .collect(Collectors.toList());
    }

    // ── 월간 스탯 ──────────────────────────────────────────────

    public List<PlayerMonthlyStatResponse> getMonthlyStats(Long playerId, Integer season) {
        return playerMonthlyStatRepository.findByPlayerIdAndSeasonOrderByMonth(playerId, season).stream()
                .map(PlayerMonthlyStatResponse::from)
                .collect(Collectors.toList());
    }

    // ── 스플릿 스탯 ────────────────────────────────────────────

    public List<BatterSituationStatResponse> getSituationStats(Long playerId, Integer season, String gameType) {
        return batterSituationStatRepository.findByPlayerIdAndSeason(playerId, season).stream()
                .filter(s -> s.getGameType().equals(gameType))
                .map(BatterSituationStatResponse::from)
                .collect(Collectors.toList());
    }

    public BatterSituationStatResponse getSituationStatBySitCode(Long playerId, Integer season, String sitCode, String gameType) {
        return batterSituationStatRepository.findByPlayerIdAndSeason(playerId, season).stream()
                .filter(s -> s.getSitCode().equals(sitCode) && s.getGameType().equals(gameType))
                .findFirst()
                .map(BatterSituationStatResponse::from)
                .orElseThrow(() -> ApiException.notFound(
                        "스플릿 스탯을 찾을 수 없습니다: playerId=" + playerId + ", sitCode=" + sitCode + ", gameType=" + gameType));
    }

    // ── 타자 vs 투수 ───────────────────────────────────────────

    public List<BatterVsPitcherResponse> getBatterVsPitcher(Long batterId, Integer season, String gameType) {
        return batterVsPitcherRepository.findByBatterIdAndSeason(batterId, season).stream()
                .filter(r -> r.getGameType().equals(gameType))
                .sorted(Comparator.comparing(BatterVsPitcher::getAtBats).reversed())
                .map(BatterVsPitcherResponse::from)
                .collect(Collectors.toList());
    }

    public List<BatterVsPitcherResponse> getPitcherVsBatter(Long pitcherId, Integer season, String gameType) {
        return batterVsPitcherRepository.findByPitcherIdAndSeason(pitcherId, season).stream()
                .filter(r -> r.getGameType().equals(gameType))
                .sorted(Comparator.comparing(BatterVsPitcher::getAtBats).reversed())
                .map(BatterVsPitcherResponse::from)
                .collect(Collectors.toList());
    }

    public BatterVsPitcherResponse getBatterVsPitcherDetail(Long batterId, Long pitcherId, Integer season, String gameType) {
        return batterVsPitcherRepository.findByBatterIdAndSeason(batterId, season).stream()
                .filter(r -> r.getPitcher().getId().equals(pitcherId) && r.getGameType().equals(gameType))
                .findFirst()
                .map(BatterVsPitcherResponse::from)
                .orElseThrow(() -> ApiException.notFound(
                        "타자 vs 투수 데이터를 찾을 수 없습니다: batterId=" + batterId + ", pitcherId=" + pitcherId));
    }
}