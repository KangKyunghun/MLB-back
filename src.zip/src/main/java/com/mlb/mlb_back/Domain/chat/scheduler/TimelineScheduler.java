package com.mlb.mlb_back.Domain.chat.scheduler;

import com.mlb.mlb_back.Domain.chat.entity.ChatRoom;
import com.mlb.mlb_back.Domain.chat.repository.ChatRoomRepository;
import com.mlb.mlb_back.Domain.chat.service.ChatService;
import com.mlb.mlb_back.Domain.chat.service.TimelineService;
import com.mlb.mlb_back.Domain.game.entity.Game;
import com.mlb.mlb_back.Domain.game.repository.GameRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class TimelineScheduler {

    private final GameRepository gameRepository;
    private final ChatRoomRepository chatRoomRepository;
    private final ChatService chatService;
    private final TimelineService timelineService;

    /**
     * 30초마다 오늘 Live 경기 감지 → 채팅방 자동 생성/활성화
     */
    @Scheduled(fixedDelay = 30_000)
    @Transactional
    public void detectLiveGames() {
        LocalDateTime startOfDay = LocalDate.now().atStartOfDay();
        LocalDateTime endOfDay = startOfDay.plusDays(1);

        List<Game> liveGames = gameRepository
                .findByStatusAndGameDateBetween("Live", startOfDay, endOfDay);

        for (Game game : liveGames) {
            chatRoomRepository.findByGame_Id(game.getId()).ifPresentOrElse(
                    room -> {
                        if (!room.getIsActive()) {
                            room.activate();
                            chatRoomRepository.save(room);
                            log.info("채팅방 활성화: {}", room.getRoomName());
                        }
                    },
                    () -> {
                        // 채팅방 없으면 생성
                        String roomName = game.getAwayTeam().getAbbreviation()
                                + " vs " + game.getHomeTeam().getAbbreviation();

                        ChatRoom newRoom = ChatRoom.builder()
                                .game(game)
                                .roomName(roomName)
                                .build();
                        newRoom.activate();
                        ChatRoom saved = chatRoomRepository.save(newRoom);
                        chatService.sendSystemMessage(saved.getId(), "⚾ 경기가 시작되었습니다!");
                        log.info("채팅방 생성: {}", roomName);
                    }
            );
        }
    }

    /**
     * 20초마다 활성화된 경기 타임라인 갱신 → WebSocket 브로드캐스트
     */
    @Scheduled(fixedDelay = 20_000)
    public void refreshTimelines() {
        timelineService.refreshTimelines();
    }
}