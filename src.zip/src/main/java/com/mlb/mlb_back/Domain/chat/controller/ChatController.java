package com.mlb.mlb_back.Domain.chat.controller;

import com.mlb.mlb_back.Domain.chat.dto.ChatMessageRequest;
import com.mlb.mlb_back.Domain.chat.dto.ChatMessageResponse;
import com.mlb.mlb_back.Domain.chat.dto.ChatRoomResponse;
import com.mlb.mlb_back.Domain.chat.service.ChatService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.security.Principal;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;

    // ──────────────────────────────────────────────
    // REST API
    // ──────────────────────────────────────────────

    /**
     * 경기별 채팅방 조회 (없으면 자동 생성)
     * GET /api/chat/rooms/game/{gamePk}
     */
    @GetMapping("/api/chat/rooms/game/{gamePk}")
    public ResponseEntity<ChatRoomResponse> getChatRoom(@PathVariable Long gamePk) {
        return ResponseEntity.ok(chatService.getOrCreateChatRoom(gamePk));
    }

    /**
     * 활성화된 채팅방 목록 (현재 진행중인 경기)
     * GET /api/chat/rooms/active
     */
    @GetMapping("/api/chat/rooms/active")
    public ResponseEntity<List<ChatRoomResponse>> getActiveChatRooms() {
        return ResponseEntity.ok(chatService.getActiveChatRooms());
    }

    /**
     * 입장 시 이전 메시지 조회 (최근 50개)
     * GET /api/chat/rooms/{chatRoomId}/messages
     */
    @GetMapping("/api/chat/rooms/{chatRoomId}/messages")
    public ResponseEntity<List<ChatMessageResponse>> getRecentMessages(
            @PathVariable Long chatRoomId) {
        return ResponseEntity.ok(chatService.getRecentMessages(chatRoomId));
    }

    // ──────────────────────────────────────────────
    // STOMP WebSocket
    // ──────────────────────────────────────────────

    /**
     * 채팅 메시지 전송
     * 클라이언트: stompClient.send("/app/chat/{chatRoomId}", {}, JSON.stringify({content: "..."}))
     * 브로드캐스트: /topic/chat/{chatRoomId}
     */
    @MessageMapping("/chat/{chatRoomId}")
    public void sendMessage(
            @DestinationVariable Long chatRoomId,
            ChatMessageRequest request,
            Principal principal) {

        if (principal == null) {
            throw new IllegalStateException("로그인이 필요합니다");
        }

        chatService.sendMessage(chatRoomId, principal.getName(), request.getContent());
    }
}