package com.mlb.mlb_back.Domain.chat.dto;

import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class TimelineEvent {

    // 이벤트 타입
    // PLAY          - 일반 타석 결과 (아웃, 안타 등)
    // SCORE_CHANGE  - 득점 발생
    // STOLEN_BASE   - 도루 성공
    // CAUGHT_STEALING - 도루 실패
    // PITCHING_CHANGE - 투수 교체
    // INNING_CHANGE - 이닝 변경
    // GAME_END      - 경기 종료
    private String type;

    private Integer inning;
    private String halfInning;          // "top"(초) / "bottom"(말)

    // 타석 정보
    private String batterName;          // 타자 이름
    private String pitcherName;         // 투수 이름
    private String description;         // 플레이 결과 설명 (예: "2루수 라인드라이브 아웃")

    // 투구 시퀀스 (스트라이크/볼/타격 순서)
    private List<PitchSequence> pitches;

    // 득점 정보
    private List<String> scoringPlayers; // 득점한 선수 이름 목록
    private Integer homeScore;
    private Integer awayScore;

    // 도루
    private String stolenBasePlayer;    // 도루 시도 선수
    private String stolenBase;          // 도루 베이스 (2B, 3B, HOME)

    // 투수 교체
    private String outgoingPitcher;     // 교체 나간 투수
    private String incomingPitcher;     // 들어온 투수

    private String atBatIndex;

    @Getter
    @Builder
    public static class PitchSequence {
        private Integer pitchNumber;
        private String type;            // S(스트라이크), B(볼), X(타격), H(헛스윙)
        private String description;     // "스트라이크", "볼", "타격" 등
    }
}