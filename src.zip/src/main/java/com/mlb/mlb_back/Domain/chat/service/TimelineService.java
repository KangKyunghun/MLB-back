package com.mlb.mlb_back.Domain.chat.service;

import com.mlb.mlb_back.Domain.chat.dto.TimelineEvent;
import com.mlb.mlb_back.Domain.chat.entity.ChatRoom;
import com.mlb.mlb_back.Domain.chat.repository.ChatRoomRepository;
import com.mlb.mlb_back.Domain.game.entity.Game;
import com.mlb.mlb_back.Domain.game.repository.GameRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Service
@RequiredArgsConstructor
public class TimelineService {

    private final WebClient webClient;
    private final SimpMessagingTemplate messagingTemplate;
    private final ChatRoomRepository chatRoomRepository;
    private final GameRepository gameRepository;
    private final ChatService chatService;

    // 마지막으로 처리한 플레이 인덱스 (gamePk → atBatIndex)
    private final Map<Long, Integer> lastPlayIndex = new ConcurrentHashMap<>();

    /**
     * 진행중인 경기 타임라인 갱신 (스케줄러에서 호출)
     */
    public void refreshTimelines() {
        List<ChatRoom> activeRooms = chatRoomRepository.findByIsActiveTrue();

        for (ChatRoom room : activeRooms) {
            Long gamePk = room.getGame().getId();
            try {
                fetchAndBroadcastTimeline(gamePk, room.getId());
            } catch (Exception e) {
                log.error("타임라인 갱신 실패 gamePk={}: {}", gamePk, e.getMessage());
            }
        }
    }

    /**
     * 특정 경기 타임라인 전체 조회 (클라이언트 최초 진입 시)
     */
    @SuppressWarnings("unchecked")
    public List<TimelineEvent> getFullTimeline(Long gamePk) {
        List<TimelineEvent> events = new ArrayList<>();

        try {
            Map<String, Object> response = webClient.get()
                    .uri("/game/{gamePk}/playByPlay", gamePk)
                    .retrieve()
                    .bodyToMono(Map.class)
                    .block();

            if (response == null) return events;

            List<Map<String, Object>> allPlays =
                    (List<Map<String, Object>>) response.get("allPlays");

            if (allPlays == null) return events;

            for (Map<String, Object> play : allPlays) {
                TimelineEvent event = parsePlay(play);
                if (event != null) events.add(event);
            }

        } catch (Exception e) {
            log.error("타임라인 전체 조회 실패 gamePk={}: {}", gamePk, e.getMessage());
        }

        return events;
    }

    /**
     * MLB API에서 새 플레이 가져와서 WebSocket으로 브로드캐스트
     */
    @SuppressWarnings("unchecked")
    private void fetchAndBroadcastTimeline(Long gamePk, Long chatRoomId) {
        Map<String, Object> response = webClient.get()
                .uri("/game/{gamePk}/playByPlay", gamePk)
                .retrieve()
                .bodyToMono(Map.class)
                .block();

        if (response == null) return;

        List<Map<String, Object>> allPlays =
                (List<Map<String, Object>>) response.get("allPlays");

        if (allPlays == null || allPlays.isEmpty()) return;

        int lastIndex = lastPlayIndex.getOrDefault(gamePk, -1);

        for (Map<String, Object> play : allPlays) {
            Object atBatObj = play.get("atBatIndex");
            if (atBatObj == null) continue;
            int atBatIndex = ((Number) atBatObj).intValue();

            if (atBatIndex <= lastIndex) continue;

            TimelineEvent event = parsePlay(play);
            if (event == null) continue;

            // 타임라인 구독자에게 push
            messagingTemplate.convertAndSend("/topic/timeline/" + gamePk, event);

            // 득점 변경 시 채팅방에 시스템 메시지
            if ("SCORE_CHANGE".equals(event.getType())) {
                String msg = String.format("⚾ %s [%d이닝 %s] %s (%d - %d)",
                        event.getType().equals("SCORE_CHANGE") ? "득점!" : "",
                        event.getInning(),
                        "top".equals(event.getHalfInning()) ? "초" : "말",
                        event.getDescription(),
                        event.getAwayScore(),
                        event.getHomeScore());
                chatService.sendSystemMessage(chatRoomId, msg);
            }

            lastPlayIndex.put(gamePk, atBatIndex);
        }

        // 경기 종료 감지
        checkGameEnd(gamePk, chatRoomId, response);
    }

    /**
     * MLB API 플레이 데이터 → TimelineEvent 파싱
     */
    @SuppressWarnings("unchecked")
    private TimelineEvent parsePlay(Map<String, Object> play) {
        try {
            Map<String, Object> about = (Map<String, Object>) play.get("about");
            Map<String, Object> result = (Map<String, Object>) play.get("result");

            if (about == null || result == null) return null;

            int inning = ((Number) about.get("inning")).intValue();
            String halfInning = (String) about.get("halfInning"); // "top" or "bottom"
            String description = (String) result.get("description");
            int atBatIndex = ((Number) about.get("atBatIndex")).intValue();

            // 득점 변경 여부
            Object awayScoreObj = result.get("awayScore");
            Object homeScoreObj = result.get("homeScore");
            int awayScore = awayScoreObj != null ? ((Number) awayScoreObj).intValue() : 0;
            int homeScore = homeScoreObj != null ? ((Number) homeScoreObj).intValue() : 0;

            // rbi가 있으면 득점 이벤트
            Object rbiObj = result.get("rbi");
            int rbi = rbiObj != null ? ((Number) rbiObj).intValue() : 0;
            String type = rbi > 0 ? "SCORE_CHANGE" : "PLAY";

            return TimelineEvent.builder()
                    .type(type)
                    .inning(inning)
                    .halfInning(halfInning)
                    .description(description)
                    .homeScore(homeScore)
                    .awayScore(awayScore)
                    .atBatIndex(String.valueOf(atBatIndex))
                    .build();

        } catch (Exception e) {
            log.warn("플레이 파싱 실패: {}", e.getMessage());
            return null;
        }
    }

    /**
     * 경기 종료 감지 → 채팅방 비활성화
     */
    @SuppressWarnings("unchecked")
    private void checkGameEnd(Long gamePk, Long chatRoomId, Map<String, Object> response) {
        try {
            Map<String, Object> gameData = (Map<String, Object>) response.get("gameData");
            if (gameData == null) return;

            Map<String, Object> status = (Map<String, Object>) gameData.get("status");
            if (status == null) return;

            String abstractGameState = (String) status.get("abstractGameState");

            if ("Final".equalsIgnoreCase(abstractGameState)) {
                chatRoomRepository.findById(chatRoomId).ifPresent(room -> {
                    room.deactivate();
                    chatRoomRepository.save(room);
                    chatService.sendSystemMessage(chatRoomId, "⚾ 경기가 종료되었습니다.");
                    // 타임라인 종료 이벤트 push
                    messagingTemplate.convertAndSend("/topic/timeline/" + gamePk,
                            TimelineEvent.builder().type("GAME_END").build());
                    lastPlayIndex.remove(gamePk);
                    log.info("경기 종료 처리 gamePk={}", gamePk);
                });
            }
        } catch (Exception e) {
            log.error("경기 종료 감지 실패: {}", e.getMessage());
        }
    }
}